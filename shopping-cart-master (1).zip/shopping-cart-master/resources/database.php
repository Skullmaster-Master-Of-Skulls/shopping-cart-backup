<?php

$servername = "localhost";
$username = "root";
$password = "";
$schema = "irohsteahouse";

// Connection
$conn = @mysqli_connect($servername, $username, $password, $schema);

?>