The resources folders contains resources files we don't want generally accessible through
the public_html folder. This may include database access, functions, templates, etc.
