The img folder is where all images for the site will be stored.
