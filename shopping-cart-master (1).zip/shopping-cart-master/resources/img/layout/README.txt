The layout folder is where all site images (not product images) will be stored.
