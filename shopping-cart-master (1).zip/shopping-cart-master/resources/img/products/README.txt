The products folder is where all product images for the site will be stored.
