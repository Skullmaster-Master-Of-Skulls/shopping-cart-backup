<?php

if (isset($_GET['policy-declined'])) {
	echo "<div id='policy-declined'>";
	echo "<p>Your account has been deactivated as you have declined our Privacy Policy.<br> If you change your mind
					 in the future, simply login and accept our policy to reactivate your account.</p>";
	echo "</div>";
}

?>