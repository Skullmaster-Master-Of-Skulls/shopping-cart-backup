<form id="Loginmenu" action="login.php" method="POST">
	<input type="hidden" name="login">
	<input type="text" name="username" required> Username <br>
	<input type="password" name="password" required> Password <br>
	<button type="submit">Login</button>
	<button disabled><a href="createAccount.php">Create Account</a></button>
</form>