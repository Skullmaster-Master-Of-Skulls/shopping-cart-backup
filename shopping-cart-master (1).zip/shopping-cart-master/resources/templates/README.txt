The templates folder is used to store site templates for commonly reused HTML / PHP. This may include header.php, footer.php, etc.
