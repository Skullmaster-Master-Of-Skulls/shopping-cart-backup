<div class="nav">
<a href="admin.php"><img id="Logo" src="../resources/img/Lotus.png"><span id="IrohTitle"><h2>Iroh's Tea House</h2></span> </a>
	<div id="navbuttons">
		<a class="Navbutton" id="Createbutton">Create new item</a>
		<a class="Navbutton" id="USERNAME"> <?php echo "Welcome back, " . $_SESSION['username'] ?></a>
		<a href="logout.php" class="Navbutton" id="Logoutbutton">Log out</a>
	</div>
</div>