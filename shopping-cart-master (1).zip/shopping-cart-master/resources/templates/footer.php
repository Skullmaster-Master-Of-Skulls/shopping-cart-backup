<footer>
	<div id="contact">
		<a class="Contactbutton">About Us</a>
		<a class="Contactbutton">Contact Us</a>      
		<a href="privacypolicy.php" class="Contactbutton">Privacy policy</a>
	</div>
	<p id="copyright">Copyright Iroh's Tea House 2020</p>
</footer>	