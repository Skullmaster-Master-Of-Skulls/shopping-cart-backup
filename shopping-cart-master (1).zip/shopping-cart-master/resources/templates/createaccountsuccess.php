<?php

if (isset($_GET['account-created-successfully'])) {
	echo "<div id='account-created'>";
	echo "<p>Account Created Successfully.</p>";
	echo "</div>";
}

?>