The library folder may be used to store all significant functions in a single location
