The public_html folder acts as the launch point for websites on the internet.
All the main site content will reside here.
