The css folder is where all CSS for the site will be stored.
