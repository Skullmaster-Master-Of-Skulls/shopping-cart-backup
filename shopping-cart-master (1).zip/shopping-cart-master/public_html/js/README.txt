The js folder is where all Javascript for the site will be stored.
